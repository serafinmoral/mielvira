/*
 * Selective_Classifier.java
 *
 * Created on 10 de mayo de 2004, 13:35
 */

package elvira.learning.classification.supervised.mixed;

/**
 * Implementation of a interface to define variable selection in a 
 * classifier method. 
 * @author  andrew
 */
public interface Selective_Classifier {
    
      
}


