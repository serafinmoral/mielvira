package elvira.probabilisticDecisionGraph.tools;

public class VectorOpsException extends Exception {

	public VectorOpsException(String string) {
		super(string);
	}
}
