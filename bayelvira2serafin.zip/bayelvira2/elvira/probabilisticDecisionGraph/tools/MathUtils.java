package elvira.probabilisticDecisionGraph.tools;

public class MathUtils {
	public static final double log2(double a){
		return Math.log(a) / Math.log(2);
	}
}
