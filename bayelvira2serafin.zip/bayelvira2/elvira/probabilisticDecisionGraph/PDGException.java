package elvira.probabilisticDecisionGraph;

public class PDGException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2014621622965336862L;

	public PDGException(String msg){ super(msg); } 

}
