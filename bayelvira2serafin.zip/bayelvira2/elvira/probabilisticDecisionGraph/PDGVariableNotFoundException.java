package elvira.probabilisticDecisionGraph;

public class PDGVariableNotFoundException extends PDGException {

	public PDGVariableNotFoundException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1791715313495984007L;

}
