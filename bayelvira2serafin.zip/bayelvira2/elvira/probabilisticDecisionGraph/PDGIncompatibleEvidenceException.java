package elvira.probabilisticDecisionGraph;

public class PDGIncompatibleEvidenceException extends PDGException {

	public PDGIncompatibleEvidenceException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 874108222977131075L;

}
